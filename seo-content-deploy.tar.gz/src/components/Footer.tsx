import { Link } from "react-router-dom";
import { BookOpen } from "lucide-react";
import { provinces } from "@/data/southAfricaLocations";

export const Footer = () => {
  return (
    <footer className="border-t border-border bg-muted/30">
      <div className="container-wide py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <BookOpen className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-display text-lg font-bold">StudyBuddy Works</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              AI-powered tutoring for South African students. CAPS-aligned learning for Grades 1-12.
            </p>
          </div>
          
          <div>
            <h4 className="font-display font-semibold mb-4">Provinces</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {provinces.slice(0, 5).map(province => (
                <li key={province.slug}>
                  <Link to={`/province/${province.slug}`} className="hover:text-foreground transition-colors">
                    {province.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-display font-semibold mb-4">More Provinces</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {provinces.slice(5).map(province => (
                <li key={province.slug}>
                  <Link to={`/province/${province.slug}`} className="hover:text-foreground transition-colors">
                    {province.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h4 className="font-display font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/locations" className="hover:text-foreground transition-colors">All Locations</Link></li>
              <li><a href="https://www.education.gov.za/" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition-colors">Dept. of Basic Education</a></li>
              <li><a href="https://www.education.gov.za/Curriculum/CurriculumAssessmentPolicyStatements(CAPS).aspx" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition-colors">CAPS Curriculum</a></li>
              <li><a href="https://www.education.gov.za/Curriculum/NationalSeniorCertificate(NSC)Examinations.aspx" target="_blank" rel="noopener noreferrer" className="hover:text-foreground transition-colors">NSC Examinations</a></li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-border">
          <p className="text-center text-sm text-muted-foreground mb-4">
            StudyBuddy Works is an independent educational technology platform. We are not affiliated with the South African Department of Basic Education, but our content is fully aligned with the official CAPS curriculum.
          </p>
          <p className="text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} StudyBuddy Works. Empowering South African students everywhere.
          </p>
        </div>
      </div>
    </footer>
  );
};
