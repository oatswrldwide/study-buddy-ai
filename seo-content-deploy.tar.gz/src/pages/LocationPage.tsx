import { useParams, Link } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { getLocationBySlug, getNearbyLocations } from "@/data/southAfricaLocations";
import { BookOpen, CheckCircle, GraduationCap, MapPin, Sparkles } from "lucide-react";

const LocationPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const location = getLocationBySlug(slug || "");
  const nearbyLocations = getNearbyLocations(slug || "", 6);

  if (!location) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="font-display text-2xl font-bold mb-4">Location not found</h2>
            <Button asChild><Link to="/locations">Browse All Locations</Link></Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  const subjects = ["Mathematics", "Physical Science", "Life Sciences", "English", "Afrikaans", "Accounting", "History", "Geography"];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/5 via-background to-secondary/5 section-padding">
        <div className="container-wide">
          <div className="max-w-3xl">
            {/* Breadcrumb */}
            <div className="text-sm text-muted-foreground mb-4">
              <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
              <span className="mx-2">/</span>
              <Link to="/locations" className="hover:text-foreground transition-colors">Locations</Link>
              <span className="mx-2">/</span>
              <Link to={`/province/${location.provinceSlug}`} className="hover:text-foreground transition-colors">{location.province}</Link>
              <span className="mx-2">/</span>
              <span className="text-foreground">{location.name}</span>
            </div>
            
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-4">
              <MapPin className="h-4 w-4" />
              <Link to={`/province/${location.provinceSlug}`} className="hover:underline">
                {location.province}
              </Link>
            </div>
            
            <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              AI Tutor in <span className="text-gradient">{location.name}</span>
            </h1>
            
            <p className="text-lg text-muted-foreground mb-6">
              Get personalized, CAPS-aligned tutoring for students in {location.name}, {location.province}. Our AI tutor helps with homework, exam prep, and understanding difficult concepts—available 24/7.
            </p>
            
            <p className="text-muted-foreground mb-6">
              Whether you're preparing for tests, working on assignments, or studying for your <a href="https://www.education.gov.za/Curriculum/NationalSeniorCertificate(NSC)Examinations.aspx" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Matric exams</a>, StudyBuddy Works provides instant help aligned with the South African <a href="https://www.education.gov.za/Curriculum/CurriculumAssessmentPolicyStatements(CAPS).aspx" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">CAPS curriculum</a>. Students in {location.name} can access expert-level tutoring without traveling to expensive tutoring centers.
            </p>
            
            <Button variant="hero" size="xl">
              Start Learning in {location.name}
            </Button>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="section-padding">
        <div className="container-wide">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-8">
            Why Choose StudyBuddy Works in {location.name}?
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            {[
              "24/7 availability - study whenever you need",
              "Aligned with South African CAPS curriculum",
              "Instant help with homework and assignments",
              "Exam preparation for all grade levels",
              "Personalized learning pace",
              "Covers all subjects from Grade 1-12"
            ].map((benefit, i) => (
              <div key={i} className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                <span>{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Subjects */}
      <section className="section-padding bg-muted/30">
        <div className="container-wide">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-4">
            Subjects We Cover in {location.name}
          </h2>
          <p className="text-muted-foreground mb-8 max-w-3xl">
            Our AI tutor covers all CAPS subjects for Grades 1-12. From Foundation Phase basics to FET phase advanced content, students in {location.name} receive comprehensive support across the full curriculum specified by the <a href="https://www.education.gov.za/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Department of Basic Education</a>.
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {subjects.map((subject) => (
              <div key={subject} className="card-elevated p-4 text-center">
                <GraduationCap className="h-8 w-8 text-primary mx-auto mb-2" />
                <span className="font-medium">{subject}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About AI Tutoring in Location */}
      <section className="section-padding">
        <div className="container-wide">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display text-2xl md:text-3xl font-bold mb-6 text-center">
              How AI Tutoring Benefits Students in {location.name}
            </h2>
            <div className="prose prose-lg max-w-none">
              <p className="text-muted-foreground mb-4">
                Traditional tutoring can be expensive and inconvenient, especially for families in {location.name} who may face challenges with transportation, scheduling, or finding qualified tutors. StudyBuddy Works eliminates these barriers by providing world-class AI-powered tutoring that's accessible from any device, any time.
              </p>
              <p className="text-muted-foreground mb-4">
                Our AI tutor understands the South African education system inside and  out. It knows the CAPS curriculum requirements, common challenges students face at each grade level, and how to explain concepts in ways that resonate with South African learners. Students in {location.name} get the same quality of tutoring as students anywhere in the country—or the world.
              </p>
              <p className="text-muted-foreground mb-4">
                Whether you're a parent looking for homework help, a Grade 12 student preparing for final exams, or a younger learner building foundational skills, StudyBuddy Works adapts to your needs. The AI remembers what you've learned, identifies knowledge gaps, and provides targeted practice to help you improve.
              </p>
              <p className="text-muted-foreground">
                Education is a right for every South African child. By making high-quality tutoring accessible and affordable in {location.name}, we're helping to level the playing field and give every student the opportunity to reach their full potential. Learn more about South African education initiatives at the <a href="https://www.education.gov.za/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline font-medium">Department of Basic Education website</a>.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section-padding bg-muted/30">
        <div className="container-narrow">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-8 text-center">
            Common Questions from {location.name} Students
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-lg mb-2">Do I need internet access to use StudyBuddy Works in {location.name}?</h3>
              <p className="text-muted-foreground">Yes, you'll need an internet connection to access our AI tutor. StudyBuddy Works is a web-based platform that works on any device with internet access—smartphones, tablets, laptops, or desktop computers.</p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Is the content really aligned with what we learn in {location.province} schools?</h3>
              <p className="text-muted-foreground">Absolutely. South Africa has a national curriculum (CAPS) that's the same across all provinces. Whether you're in {location.name} or anywhere else in {location.province} or South Africa, you're learning the same content. Our AI tutor follows this national curriculum exactly.</p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Can StudyBuddy Works help me prepare for my Matric exams?</h3>
              <p className="text-muted-foreground">Yes! Many Grade 12 students in {location.name} use StudyBuddy Works for Matric exam preparation. Get help with difficult topics, practice past paper questions, and build confidence for your NSC examinations. Our AI tutor knows the exam format and common question types.</p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">What makes AI tutoring different from YouTube videos or textbooks?</h3>
              <p className="text-muted-foreground">Unlike passive learning from videos or textbooks, AI tutoring is interactive and personalized. You can ask follow-up questions, get explanations tailored to your level, and work through problems step-by-step with guidance. It's like having a patient tutor who adapts to your learning style.</p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">How much does it cost for students in {location.name}?</h3>
              <p className="text-muted-foreground">We offer flexible pricing plans to suit different budgets, including a free tier to get started. Our goal is to make quality education accessible to all South African students, regardless of economic background or location.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Nearby Locations */}
      <section className="section-padding">
        <div className="container-wide">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-8">
            Also Available Near {location.name}
          </h2>
          
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
            {nearbyLocations.map((loc) => (
              <Link
                key={loc.slug}
                to={`/tutor/${loc.slug}`}
                className="card-elevated p-4 hover:-translate-y-1 transition-all group"
              >
                <h3 className="font-semibold group-hover:text-primary transition-colors">
                  AI Tutor in {loc.name}
                </h3>
                <p className="text-sm text-muted-foreground">{loc.province}</p>
              </Link>
            ))}
          </div>
          
          <div className="mt-8 text-center">
            <Button asChild variant="outline" size="lg">
              <Link to={`/province/${location.provinceSlug}`}>
                View All {location.province} Locations
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-narrow text-center">
          <h2 className="font-display text-2xl md:text-3xl font-bold mb-4">
            Ready to Start Learning in {location.name}?
          </h2>
          <p className="text-primary-foreground/80 mb-6">
            Join students across {location.province} who are improving their grades with AI tutoring.
          </p>
          <Button variant="cta" size="xl">
            Get Started Free
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default LocationPage;
