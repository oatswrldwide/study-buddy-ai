import { useParams, Link } from "react-router-dom";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { getProvinceBySlug, getLocationsByProvince } from "@/data/southAfricaLocations";
import { MapPin } from "lucide-react";

const ProvincePage = () => {
  const { slug } = useParams<{ slug: string }>();
  const province = getProvinceBySlug(slug || "");
  const locations = getLocationsByProvince(slug || "");

  if (!province) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h2 className="font-display text-2xl font-bold mb-4">Province not found</h2>
            <Button asChild><Link to="/locations">Browse All Locations</Link></Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <section className="bg-gradient-to-br from-primary/5 via-background to-secondary/5 section-padding">
        <div className="container-wide">
          {/* Breadcrumb */}
          <div className="text-sm text-muted-foreground mb-4">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <span className="mx-2">/</span>
            <Link to="/locations" className="hover:text-foreground transition-colors">Locations</Link>
            <span className="mx-2">/</span>
            <span className="text-foreground">{province.name}</span>
          </div>
          
          <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
            AI Tutoring in <span className="text-gradient">{province.name}</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mb-4">
            StudyBuddy Works provides CAPS-aligned AI tutoring across {locations.length} towns and suburbs in {province.name}. Find your local area below.
          </p>
          <p className="text-muted-foreground max-w-3xl">
            Every student in {province.name} deserves access to quality education support. Whether you're in a major city or a small town, our AI tutor brings expert-level help directly to your device. All content follows the official South African <a href="https://www.education.gov.za/Curriculum/CurriculumAssessmentPolicyStatements(CAPS).aspx" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">CAPS curriculum</a> for Grades 1-12, ensuring you learn exactly what's needed for your exams and future success.
          </p>
        </div>
      </section>

      <section className="section-padding">
        <div className="container-wide">
          <h2 className="font-display text-2xl font-bold mb-4 flex items-center gap-2">
            <MapPin className="h-6 w-6 text-primary" />
            All Locations in {province.name}
          </h2>
          <p className="text-muted-foreground mb-8 max-w-3xl">
            Select your town or suburb below to learn more about AI tutoring services in your specific area. Each location has dedicated support tailored to local students following the national CAPS curriculum.
          </p>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {locations.map((location) => (
              <Link
                key={location.slug}
                to={`/tutor/${location.slug}`}
                className="card-elevated p-3 hover:-translate-y-0.5 transition-all group text-center"
              >
                <span className="font-medium group-hover:text-primary transition-colors text-sm">
                  {location.name}
                </span>
              </Link>
            ))}
          </div>
          
          <div className="mt-12 max-w-4xl mx-auto">
            <h3 className="font-display text-xl font-bold mb-4">
              Quality Education Support Across {province.name}
            </h3>
            <p className="text-muted-foreground mb-4">
              {province.name} is home to diverse communities with students at all levels of learning. StudyBuddy Works ensures that every learner, regardless of their location within the province, has access to the same high-quality AI tutoring that adapts to their individual needs and learning pace.
            </p>
            <p className="text-muted-foreground mb-4">
              Our AI tutor covers all subjects mandated by the <a href="https://www.education.gov.za/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Department of Basic Education</a>, including Mathematics, Sciences, Languages, and Humanities. Students can get help with daily homework, prepare for tests and exams, or work on understanding challenging concepts that they find difficult in the classroom.
            </p>
            <p className="text-muted-foreground">
              Education transforms lives and communities. By making AI tutoring accessible throughout {province.name}, we're helping to ensure that every student has the tools they need to succeed academically and reach their full potential, regardless of their family's economic circumstances or geographic location.
            </p>
          </div>
          
          <div className="mt-12 text-center">
            <Button asChild variant="outline" size="lg">
              <Link to="/locations">
                Browse All South African Locations
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ProvincePage;
