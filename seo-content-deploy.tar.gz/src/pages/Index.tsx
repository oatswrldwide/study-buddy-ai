import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { provinces, getTotalLocationCount } from "@/data/southAfricaLocations";
import { BookOpen, Brain, GraduationCap, MapPin, Sparkles, Users, CheckCircle } from "lucide-react";

const Index = () => {
  const totalLocations = getTotalLocationCount();

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        <div className="container-wide section-padding">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary mb-6 animate-fade-in">
              <Sparkles className="h-4 w-4" />
              AI-Powered Learning for South African Schools
            </div>
            
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold mb-6 animate-fade-in" style={{ animationDelay: "0.1s" }}>
              Your Personal <span className="text-gradient">AI Tutor</span> in Every South African Town
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground mb-8 animate-fade-in" style={{ animationDelay: "0.2s" }}>
              CAPS-aligned tutoring for Grades 1-12. Get personalized help with Maths, Science, English, and all subjects—available 24/7 in {totalLocations}+ locations across South Africa.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{ animationDelay: "0.3s" }}>
              <Button variant="hero" size="xl">
                Start Learning Free
              </Button>
              <Button variant="outline" size="xl" asChild>
                <Link to="/locations">
                  <MapPin className="h-5 w-5 mr-2" />
                  Find Your Town
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About CAPS Section */}
      <section className="section-padding">
        <div className="container-wide">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-6">
              Fully Aligned with South Africa's CAPS Curriculum
            </h2>
            <p className="text-lg text-center text-muted-foreground mb-8">
              StudyBuddy Works follows the official <a href="https://www.education.gov.za/Curriculum/CurriculumAssessmentPolicyStatements(CAPS).aspx" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Curriculum and Assessment Policy Statement (CAPS)</a> set by the South African Department of Basic Education. Every lesson, exercise, and explanation is designed to help students master the exact skills and knowledge required for their grade level.
            </p>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold text-primary mb-2">Grades 1-12</div>
                <p className="text-sm text-muted-foreground">Complete curriculum coverage from Foundation to FET phase</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary mb-2">All Subjects</div>
                <p className="text-sm text-muted-foreground">Mathematics, Sciences, Languages, Humanities & more</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary mb-2">24/7 Access</div>
                <p className="text-sm text-muted-foreground">Study anytime, anywhere, at your own pace</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="section-padding bg-muted/30">
        <div className="container-wide">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-12">
            Why Students Love StudyBuddy Works
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Brain, title: "AI That Understands You", description: "Our AI adapts to your learning style and pace, providing personalized explanations that make sense." },
              { icon: GraduationCap, title: "CAPS Curriculum Aligned", description: "Every lesson follows the South African CAPS curriculum from Grade 1 to Grade 12." },
              { icon: Users, title: "Available Everywhere", description: `From Johannesburg to Cape Town, from rural towns to suburbs—we serve ${totalLocations}+ locations.` }
            ].map((feature, i) => (
              <div key={i} className="card-elevated p-6 hover:-translate-y-1 transition-transform">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-display text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Provinces Grid */}
      <section className="section-padding">
        <div className="container-wide">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-4">
            AI Tutoring Across South Africa
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Select your province to find AI tutoring in your local town or suburb
          </p>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {provinces.map((province) => (
              <Link
                key={province.slug}
                to={`/province/${province.slug}`}
                className="card-elevated p-5 hover:-translate-y-1 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-display font-semibold group-hover:text-primary transition-colors">
                      {province.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {province.locations.length} locations
                    </p>
                  </div>
                  <MapPin className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="section-padding">
        <div className="container-wide">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-4">
            How AI Tutoring Works
          </h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Getting started with AI-powered learning is simple. Our intelligent tutoring system adapts to your unique learning needs.
          </p>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 text-xl font-bold text-primary">1</div>
              <h3 className="font-semibold mb-2">Ask Questions</h3>
              <p className="text-sm text-muted-foreground">Type your homework question or topic you're struggling with</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 text-xl font-bold text-primary">2</div>
              <h3 className="font-semibold mb-2">Get Explanations</h3>
              <p className="text-sm text-muted-foreground">Receive step-by-step explanations tailored to your grade level</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 text-xl font-bold text-primary">3</div>
              <h3 className="font-semibold mb-2">Practice & Learn</h3>
              <p className="text-sm text-muted-foreground">Work through examples and practice problems with guidance</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 text-xl font-bold text-primary">4</div>
              <h3 className="font-semibold mb-2">Track Progress</h3>
              <p className="text-sm text-muted-foreground">Monitor your improvement and master topics at your pace</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="section-padding bg-muted/30">
        <div className="container-narrow">
          <h2 className="font-display text-3xl md:text-4xl font-bold text-center mb-12">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-lg mb-2">Is StudyBuddy Works aligned with the CAPS curriculum?</h3>
              <p className="text-muted-foreground">Yes, absolutely. All our content follows the official <a href="https://www.education.gov.za/" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Department of Basic Education</a> CAPS curriculum for Grades 1-12. This ensures students learn exactly what they need for their grade level and exams.</p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">What subjects do you cover?</h3>
              <p className="text-muted-foreground">We cover all major CAPS subjects including Mathematics, Physical Sciences, Life Sciences, English, Afrikaans, Accounting, Economics, Geography, History, and more. Our AI tutor can help with any subject from Grade 1 to Grade 12.</p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Can I use this for Matric exam preparation?</h3>
              <p className="text-muted-foreground">Yes! StudyBuddy Works is excellent for Grade 12 (Matric) exam preparation. Get help understanding difficult concepts, practice past paper questions, and build confidence for your <a href="https://www.education.gov.za/Curriculum/NationalSeniorCertificate(NSC)Examinations.aspx" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">NSC examinations</a>.</p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">How much does it cost?</h3>
              <p className="text-muted-foreground">We offer flexible pricing plans to suit every family's budget, including a free tier to get started. Education should be accessible to all South African students, regardless of location or economic background.</p>
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-2">Is this available in my town?</h3>
              <p className="text-muted-foreground">Yes! StudyBuddy Works is available in 750+ locations across all 9 provinces of South Africa. Whether you're in a major city, small town, suburb, or rural area, you can access our AI tutoring service online 24/7.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section-padding bg-primary text-primary-foreground">
        <div className="container-narrow text-center">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            Ready to Boost Your Grades?
          </h2>
          <p className="text-primary-foreground/80 mb-8 text-lg">
            Join thousands of South African students already learning with StudyBuddy Works.
          </p>
          <Button variant="cta" size="xl">
            Get Started for Free
          </Button>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Index;
